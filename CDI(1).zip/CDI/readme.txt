# first you should run CDI/config.php
# after, run localhost/CDI/