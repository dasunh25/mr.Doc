<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <?php include 'header.php';
    include 'autologout.php';?>
</head>
<body>

<div class="container-fluid">
	<div class="row content">
		<div class="col-sm-2">
			<?php include 'sidenav.php';?>
		</div>
		<div class="col-sm-10">




		</div>
	</div>
</div>
<?php include 'footer.php';?>
</body>
</html>

