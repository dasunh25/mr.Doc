<footer class="container-fluid text-center ">
	<div class="footer-copyright text-center py-3"> Copyright © 2019 : MrDoc
		<p></p>
	</div>
</footer>
