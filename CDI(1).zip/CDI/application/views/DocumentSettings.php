<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Document Settings</title>
    <?php include 'header.php';
    include 'autologout.php';?>
</head>
<body>
<div class="container-fluid">
    <div class="row content">
        <div class="col-sm-2">
            <?php include 'sidenav.php';?>
        </div>
        <div class="col-sm-5">
                        <div class="container" style="margin-left:auto; width: 500px ">
                            <div class="row">
                                <div class="col-4 ">
                                    <div class="form">
                                        <hr/>
                                         <span style="color: midnightblue;" >
						                    <center><h1>Add Categories</h1></center>
                                         </span>
                                        <form method="post" action="<?php echo base_url();?>login_controller/insertCat">
                                            <br/>
                                            <div class="form-group">
                                                <label for="username">Category</label>
                                                <input type="text" class="form-control" id="category" name="category" placeholder="Ex : Information System / IS"/>
                                                <span class="text-danger"><?php echo form_error('category')?></span>
                                            </div>
                                            <center><button type="submit" class="btn btn-primary" name="submit" value="submit">Enter</button></center>
                                        </form>
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>
            <br/>

                        <table align="center" class="table table-hover" style="width: 90%; ">
                            <thead>
                            <tr>
                                <th>Category</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php

                            if ($fetch_data->num_rows() > 0) {
                                foreach ($fetch_data->result() as $row) {

                                    ?>
                                    <td><?php echo $row->category; ?></td>
                                    <td><a href="#" class="delete_data " id="<?php echo $row->category; ?>">Delete</a></td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                            </tbody>
                        </table>

            <script>
                $(document).ready(function () {
                    $('.delete_data').click(function () {
                        var id = $(this).attr("id");
                        if (confirm("Are you sure,You want to delete this")) {
                            window.location = "<?php echo base_url(); ?>login_controller/delete_cat/" + id;
                        } else {
                            return false;
                        }

                    })
                });
            </script>
        </div>
        <div class="col-sm-5">
            <div class="container" style="margin-left:auto; width: 500px ">
                <div class="row">
                    <div class="col-4 ">
                        <div class="form">
                            <form method="post" action="<?php echo base_url();?>login_controller/add_subject">
                                    <hr>
                                    <span style="color: midnightblue;" >
						              <center><h1>Add Subjects</h1></center>
					                </span>
                                <div class="form-group">
                                    <label for="username">Category</label>
                                    <select class="form-control" name="category">
                                        <option class="text-muted"></option>
                                        <?php
                                        if ($fetch_data->num_rows() > 0) {
                                            foreach ($fetch_data->result() as $row) {
                                                ?>
                                                <option name="category" value="<?php echo $row->category?>"><?php echo $row->category?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    <span class="text-danger"><?php echo form_error('category')?></span>
                                </div>
                                <div class="form-group">
                                    <label for="username">Subject Name</label>
                                    <input type="text" class="form-control" id="subject_name" name="subject_name" placeholder="Enter Subject Name"/>
                                    <span class="text-danger"><?php echo form_error('subject_name')?></span>
                                </div>
                                <div class="form-group">
                                    <label for="username">Subject Code</label>
                                    <input type="text" class="form-control" id="subject_code" name="subject_code" placeholder="Enter Subject Code"/>
                                    <span class="text-danger"><?php echo form_error('subject_code')?></span>
                                </div>
                                <center><button type="submit" class="btn btn-primary" name="submit" value="submit">Enter</button></center>
                            </form>
                            <hr/>
                            <form method="post" action="<?php echo base_url();?>login_controller/View_cat_details">
                                <button type="submit" class="btn btn-primary btn-block">View category details</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php include 'footer.php';?>
</body>
</html>

