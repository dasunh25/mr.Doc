<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>View Document</title>
	<?php include 'header.php';
	include 'autologout.php';?>
</head>
<body>
<div class="container-fluid">
	<div class="row content">
	<div class="col-sm-2">
		<?php include 'sidenav.php';?>
	</div>
	<div class="col-sm-10 text-left">
		<!-- content -->
	</div>
	</div>
</div>

</body>
<?php include 'footer.php';?>
</html>
