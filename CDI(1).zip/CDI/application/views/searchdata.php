<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Search</title>
	<?php include 'header.php';
	include 'autologout.php';?>
<style>
	td{
		height: 50px;
		font-size: 20px;
	}
</style>
</head>
<body>
<div class="container-fluid">
	<div class="row content">
		<div class="col-sm-2">
			<nav>
				<div class="row content">
					<div class="sidenav hidden-xs">
						<h2><div class="menucolor"><span class="glyphicon glyphicon-menu-hamburger"></span> Menu</div></h2>
						<ul class="nav nav-pills nav-stacked">
							<li class="disabled"><a href="<?php echo base_url('Home/index')?>"><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-home"></span> Home</a></li>
							<li class="disabled"><a href="<?php echo base_url('Home/viewDocument')?>">View Document <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-search"></span></a></li>
							<li class="disabled"><a href="<?php echo base_url();?>login_controller/editFile"" > Edit Document <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-edit"></span></a></li>
							<li class="disabled"><a href="<?php echo base_url();?>login_controller/uploadFile"> Upload Document<span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-upload"></span></a></li>
							<li class="active disabled"><a href="<?php echo base_url();?>login_controller/manageAccount">Manage Accounts<span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-cog"></span></a>
						</ul><br>
					</div>
				</div>
			</nav>
		</div>
		<div class="col-sm-10">
<br/>

			<form action="<?php echo base_url('login_controller/manageAccount')?>">
				<button class="btn btn-info btn-lg" style="width: 100px;"><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-chevron-left"></span>Back</button>
			</form>

			<hr align="center" width="75%"/>
			<span style="color: midnightblue;" >
				<center><h1>Search Result</h1></center>
			</span>
			<br/><br/>

			<table align="center" border="0" style="width: 500px; ">
				<tbody>



				<?php
				$n=$this->input->post('username');
				/*if (!empty($resul)){
					echo 'sssss';
				}*/
				if($n!=""){
				foreach ($result as $row) {

					?>
					<tr>
						<td>User Name :</td>
						<td><?php echo $row->username; ?></td>
					</tr>
					<tr>
						<td>Password :</td>
						<td><?php echo $row->password; ?></td>
					</tr>
					<tr>
						<td>Account type :</td>
						<td><?php echo $row->type; ?></td>
					</tr>
					<tr>
						<td>E-mail :</td>
						<td><?php echo $row->email; ?></td>
					</tr>

					<tr>
					<?php
					if ($row->type != 'admin') {
						?>
						<td><center><a href="#" class="delete_data " id="<?php echo $row->username; ?>"><button  class="btn btn-primary " style="width: 100px;">Delete</button></a></td></center>
						<?php
					}else{
						?>
							<td><center><a href="#" class="delete_data " id="<?php echo $row->username; ?>"></a></td></center>
						<?php
					}
					?><td><center><a href="<?php echo base_url();?>login_controller/update_data/<?php echo $row->username;?>"><button class="btn btn-primary" style="width: 100px;">Edit</button></a></td></center>

					</tr>
					<?php
				}
				}else{
					redirect(base_url().'login_controller/manageAccount');
				}

				?>
				</tbody>
			</table>
			<br/><br/>
			<hr align="center" width="75%"/>
			<script>
                $(document).ready(function () {
                    $('.delete_data').click(function () {
                        var id = $(this).attr("id");
                        if (confirm("Are you sure,You want to delete this")) {
                            window.location = "<?php echo base_url(); ?>login_controller/delete_data/" + id;
                        } else {
                            return false;
                        }

                    })
                });
			</script>
		</div>
	</div>
</div>
<?php include 'footer.php';?>
</body>
</html>

