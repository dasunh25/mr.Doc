<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Manage Account</title>
	<?php include 'header.php';
	include 'autologout.php';?>

</head>
<body>
<div class="container-fluid ">
	<div class="row content">
		<div class="col-sm-2 ">
			<!-- content -->
			<nav>
				<div class="row content">
					<div class="sidenav hidden-xs">
						<h2><a href="<?php echo base_url('Home/menupage')?>" class="menucolor"><span class="glyphicon glyphicon-menu-hamburger"></span> Menu</a></h2>
						<ul class="nav nav-pills nav-stacked">
							<li><a href="<?php echo base_url('Home/index')?>"><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-home"></span> Home</a></li>
							<li><a href="<?php echo base_url('Home/viewDocument')?>">View Document <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-search"></span></a></li>
							<li><a href="<?php echo base_url();?>login_controller/editFile"" > Edit Document <span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-edit"></span></a></li>
							<li><a href="<?php echo base_url();?>login_controller/uploadFile"> Upload Document<span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-upload"></span></a></li>
							<li class="active"><a href="<?php echo base_url();?>login_controller/manageAccount">Manage Accounts<span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-cog"></span></a>
                            <li><a href="<?php echo base_url()?>login_controller/Document_Settings"><span style="font-size:16px;" class="pull-right hidden-xs showopacity glyphicon glyphicon-asterisk"></span> Document Settings</a></li>
						</ul><br>
					</div>
				</div>
			</nav>
		</div>
		<div class="col-sm-7 text-left">
			<!-- content -->
			<br/>
			<div class="btn-group btn-group-justified">
				<a class="btn btn-primary">Admin Settings</a>
				<a href="<?php echo base_url('login_controller/qacForm'); ?>" class="btn btn-info btn-primary">Create QAC Accounts</a>
				<a href="<?php echo base_url('login_controller/userForm'); ?>" class="btn btn-info">Create User Accounts</a>
			</div>
			<br/>
			<h1>User Accounts and Passwords</h1>
			<br>
			<!-- search -->



			<div class="search-container" align="right">
				<form method="post" action="<?php echo base_url(); ?>login_controller/filter" >
					<table>
						<tr>
							<td><input type="text" placeholder="Search by username.." name="username" class="form-control"></td>
							<td style="padding-left: 10px;">
								<button type="submit" name="submit" value="Submit" class="btn btn-primary">Search</button>
							</td>
						</tr>
					</table>
				</form>
			</div>


			<br/>
			<table align="center" class="table table-hover" style="width: 90%; ">
				<thead>
				<tr>
					<th>User Name</th>
					<th>Password</th>
					<th>Account type</th>
					<th>E-mail</th>
					<th>Delete</th>
					<th>Update</th>
				</tr>
				</thead>
				<tbody>
				<?php

				if ($fetch_data->num_rows() > 0) {
					foreach ($fetch_data->result() as $row) {

						if ($row->type == 'admin') {
							echo "<tr bgcolor='mediumturquoise'>";
						} else {
							echo "<tr>";
						}
						?>
						<td><?php echo $row->username; ?></td>
						<td><?php echo $row->password; ?></td>
						<td><?php echo $row->type; ?></td>
						<td><?php echo $row->email; ?></td>
						<?php
						if ($row->type != 'admin') {
							?>
							<td><a href="#" class="delete_data " id="<?php echo $row->username; ?>">Delete</a></td>
							<?php
						}else{
							?>
							<td><a href="#" class="delete_data " id="<?php echo $row->username; ?>"></a></td>
							<?php
						}
						?>
						<td><a href="<?php echo base_url();?>login_controller/update_data/<?php echo $row->username;?>">Edit</a></td>

						</tr>
						<?php
					}
				}
				?>
				</tbody>
			</table>
		</div>

		<script>
            $(document).ready(function () {
                $('.delete_data').click(function () {
                    var id = $(this).attr("id");
                    if (confirm("Are you sure,You want to delete this")) {
                        window.location = "<?php echo base_url(); ?>login_controller/delete_data/" + id;
                    } else {
                        return false;
                    }

                })
            });
		</script>

		<div class="col-sm-3 sidenav1">

			<div class="container" style="margin-left:auto; width: 330px ">
				<div class="row">
					<div class="col-4">
						<form method="post" action="<?php echo base_url(); ?>login_controller/admin_account_update_validation">
							<span class="form container" style="color: #f8fff4;"><h2><center>Update Accounts</center></h2></span>
							<div class="form">
								<hr/>
								<?php
								if (isset($user_data)){
								foreach ($user_data->result() as $row){ ?>


								<div class="form-group">
									<label for="username">Username</label>
									<input style="color: #0b0b0b;" type="text" class="form-control" id="username" name="username" value="<?php echo $row->username;?>" readonly/>
									<span class="text-danger"><?php echo form_error('username') ?></span>
								</div>
								<div class="form-group">
									<label for="password">New Password / Current Password</label>
									<input type="password" class="form-control" name="password" id="password" value="" placeholder="Enter password" />
									<span class="text-danger"><?php echo form_error('password') ?></span>
								</div>

								<div class="form-group">
									<label for="password">Confirm Password</label>
									<input type="password" class="form-control" name="conpass" placeholder="Re-enter password"/>
									<span class="text-danger"><?php echo form_error('conpass') ?></span>
								</div>

								<div class="form-group">
									<label for="email">E-mail</label>
									<input type="email" class="form-control" name="email" id="email" placeholder="Enter E-mail" value="<?php echo $row->email ;?>"/>
									<span class="text-danger"><?php echo form_error(' email') ?></span>
								</div>
								<input type="hidden" name="hidden_name" value="<?php echo $row->username;?>">
								<center>
									<button type="submit" class="btn btn-primary" name="update" value="Update">Update</button>
									<?php
									if ($row->type != 'admin') {
										?>
										<td>
											<button type="submit" class=" btn btn-primary ">
												<a href="#" style="color: white;" class="delete_data " id="<?php echo $row->username; ?>">
													Delete
												</a>
											</button>
										</td>
										<?php
									}
									?>
									<center>
										<hr/>
										<span
											class="text-danger"> <?php echo $this->session->flashdata("error") ?></span>
							</div>

							<?php
							}
							}else{ ?>

							<div class="form-group">
								<label for="username">Username</label>
								<input style="color: #0b0b0b;" type="text" class="form-control" id="username" name="username"  readonly/>
								<span class="text-danger"><?php echo form_error('username') ?></span>
							</div>
							<div class="form-group">
								<label for="password">New Password / Current Password</label>
								<input type="password" class="form-control" name="password" id="password" placeholder="Enter password" />
								<span class="text-danger"><?php echo form_error('password') ?></span>
							</div>

							<div class="form-group">
								<label for="password">Confirm Password</label>
								<input type="password" class="form-control" name="conpass" id="conpass" placeholder="Re-enter password"/>
								<span class="text-danger"><?php echo form_error('conpass') ?></span>
							</div>

							<div class="form-group">
								<label for="email">E-mail</label>
								<input type="email" class="form-control" name="email" id="email" placeholder="Enter E-mail" />
								<span class="text-danger"><?php echo form_error(' email') ?></span>
							</div>
							<center>
								<button type="submit" class="btn btn-primary">Update</button>
								<?php
								if ($row->type != 'admin') {
									if ($this->input->post('username') != '') {
										?>
										<td>
											<button class="btn btn-primary ">
												<a href="#" class="delete_data " style="color: white;"
												   id="<?php echo $row->username; ?>">
													Delete
												</a>
											</button>
										</td>
										<?php
									}
								}
								?>
								<center>
									<hr/>
									<span
										class="text-danger"> <?php echo $this->session->flashdata("error") ?></span>
					</div>

					<?php }
					?>


					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<?php include 'footer.php';?>
</body>
</html>

