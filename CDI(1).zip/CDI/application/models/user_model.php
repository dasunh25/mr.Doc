<?php
class user_model extends CI_Model
{
	function can_login($username, $password,$type){
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$this->db->where('type', $type);

		$query = $this->db->get('user');
		//SELECT * FROM users WHERE username = '$username' AND password = '$password'
		if($query->num_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function fetch_data(){
		$query = $this->db->get("user");
		return $query;
		//Select * FROM users
	}

	function insert_data($data){
		$this->db->insert("user",$data); // mysqli_query("insert into user(a,b,c) values("1","2","3"));
	}

	function delete_data($id){
		$this->db->where("username",$id);
		$this->db->delete('user');
	}

	function fetch_single_data($username){
		$this->db->where('username', $username);
		$query = $this->db->get("user");
		return $query;
	}

	function update_data($data,$username){
		$this->db->where('username', $username);
		$this->db->update("user",$data);
	}

	function search_data($data){
		$this->db->like('username',$data);
		$query = $this->db->get("user");
		return $query->result();
	}

    function insert_file($data){
        $this->db->insert("fileupload",$data);
    }

    function insert_cat($data){
        $this->db->insert("category_data",$data);
    }

    function fetch_cat(){
        $query = $this->db->get("category_data");
        return $query;
    }

    function delete_cat($category){
        $this->db->where("category",$category);
        $this->db->delete('category_data');
    }

    public function create_tables($name){

        $this->load->dbforge();
        $fields = array(
            'subject_code' => array(
                'type' => 'VARCHAR',
                'constraint' => 10,
            ),
            'subject_name' => array(
                'type' => 'VARCHAR',
                'constraint' => 10
            )
        );

        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('subject_code',true);
        $this->dbforge->create_table($name);
    }

    public function delete_tables($category){
        $this->load->dbforge();
        $this->dbforge->drop_table($category,true);
    }

    function insertdata($tname,$data){
        $this->db->insert($tname,$data);
    }

    function fetch_subject($category_name){
        $this->db->order_by('subject_code', 'ASC');
        $query = $this->db->get($category_name);
        $output = '<option value="">Select Subject Code</option>';
        foreach($query->result() as $row)
        {
            $output .= '<option value="'.$row->subject_code.'">'.$row->subject_code.'</option>';
        }
        return $output;
    }






}
