<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login_controller extends CI_Controller
{

    //------------------------------------------------------------Login page
    public function login_validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('type', 'type', 'required');

        if ($this->form_validation->run()) {

            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $type = $this->input->post('type');
            //-----------------------------------
            $this->load->model('user_model');

            if ($this->user_model->can_login($username, $password, $type)) {
                $session_data = array(
                    'username' => $username,
                    'type' => $type
                );

                $this->session->set_userdata($session_data);
                redirect(base_url() . 'login_controller/enter');
                $this->session->set_userdata('username');
                $this->session->set_userdata('type');

            } else {
                $this->session->set_flashdata('error', 'Invalid Username and Password');
                redirect(base_url() . 'login_controller/login');
            }

        } else {

            $this->login();
        }

    }

    public function login()
    {
        $this->load->view('login');
    }

    public function enter()
    {
        if ($this->session->userdata('username') != '') {
            redirect(base_url() . 'Home/index');
        } else {
            redirect(base_url() . 'login_controller/login');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('username');
        session_destroy();
        redirect(base_url() . 'login_controller/login');
    }

    public function QAC_Create_validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');

        if ($this->form_validation->run()) {
            $this->load->model('user_model');
            $data = array(
                "username" => $this->input->post("username"),
                "password" => $this->input->post("password"),
                "type" => "QAC",
                "email" => $this->input->post("email")
            );
            $this->user_model->insert_data($data);
            ?>
            <script>
                window.location.href = '<?php echo base_url();?>login_controller/qacForm';
                alert('QAC Account is created');
            </script>
            <?php
            //	redirect(base_url() . 'login_controller/qacinserted');
        } else {
            $this->qacForm();
        }
    }

    public function qacForm()
    {
        $this->load->view('qacform');
    }

    public function qacinserted()
    {
        $this->qacForm();
    }

    //----------------------------------------------------------------------QAC

    public function user_Create_validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');

        if ($this->form_validation->run()) {
            $this->load->model('user_model');
            $data = array(
                "username" => $this->input->post("username"),
                "password" => $this->input->post("password"),
                "type" => "User",
                "email" => $this->input->post("email")
            );
            $this->user_model->insert_data($data);
            ?>
            <script>
                window.location.href = '<?php echo base_url();?>login_controller/userForm';
                alert('User Account is created');
            </script>
            <?php
        } else {
            $this->userForm();
        }
    }

    public function userForm()
    {
        $this->load->view('userform');
    }

    //----------------------------------------------------------------------User

    public function admin_account_update_validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('conpass', 'confirm password', 'required|matches[password]');

        if ($this->form_validation->run()) {
            $this->load->model('user_model');
            $data = array(
                "username" => $this->input->post("username"),
                "password" => $this->input->post("password"),
                "email" => $this->input->post("email")
            );
            $this->user_model->update_data($data, $this->input->post("username"));
            redirect(base_url() . "login_controller/manageAccount");
        } else {
            $this->manageAccount();
        }
    }

    public function manageAccount()
    {
        $this->load->model('user_model');
        $data["fetch_data"] = $this->user_model->fetch_data();
        $this->load->view('manageaccount', $data);
    }

    //----------------------------------------------------------------------Admin user name and password update

    public function update_data()
    {
        $username = $this->uri->segment(3);
        $this->load->model('user_model');
        $data['user_data'] = $this->user_model->fetch_single_data($username);
        $data["fetch_data"] = $this->user_model->fetch_data();
        $this->load->view('manageaccount', $data);
    }

    //------------------------------------------------------------QAC Account Update page

    public function QAC_account_update_validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('conpass', 'confirm password', 'required|matches[password]');

        if ($this->form_validation->run()) {
            $this->load->model('user_model');
            $data = array(
                "username" => $this->input->post("username"),
                "password" => $this->input->post("password"),
                "email" => $this->input->post("email")
            );

            $this->user_model->update_data($data, $this->input->post("username"));
            redirect(base_url() . "login_controller/QACaccountUpdate");

        } else {
            $this->QACaccountUpdate();
        }
    }

    //-----------------------------------------------------------User Account Update page

    public function QACaccountUpdate()
    {
        $username = $this->session->userdata('username');
        $this->load->model('user_model');
        $data['user_data'] = $this->user_model->fetch_single_data($username);
        //$data["fetch_data"] = $this->user_model->fetch_data();
        $this->load->view('QACaccountUpdate', $data);
    }

    //----------------------------------------------------------------------Admin user name and password update

    public function user_account_update_validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('conpass', 'confirm password', 'required|matches[password]');

        if ($this->form_validation->run()) {
            $this->load->model('user_model');
            $data = array(
                "username" => $this->input->post("username"),
                "password" => $this->input->post("password"),
                "email" => $this->input->post("email")
            );

            $this->user_model->update_data($data, $this->input->post("username"));
            redirect(base_url() . "login_controller/useraccountupdate");

        } else {
            $this->useraccountupdate();
        }
    }

    //----------------------------------------------------------------------Admin user name and password update

    public function useraccountupdate()
    {
        $username = $this->session->userdata('username');
        $this->load->model('user_model');
        $data['user_data'] = $this->user_model->fetch_single_data($username);
        $this->load->view('userAccountUpdate', $data);
    }

    public function delete_data()
    {
        $username = $this->uri->segment(3);
        $this->load->model('user_model');
        if ($username != '') {
            $this->user_model->delete_data($username);
        }
        redirect(base_url() . "login_controller/manageAccount");

    }

//------------------------------------------------------------Sign Up page

    public function sign_validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');

        if ($this->form_validation->run()) {
            $this->load->model('user_model');
            $data = array(
                "username" => $this->input->post("username"),
                "password" => $this->input->post("password"),
                "type" => "User",
                "email" => $this->input->post("email")
            );
            $this->user_model->insert_data($data);
            ?>
            <script>
                window.location.href = '<?php echo base_url();?>login_controller/login';
                alert('User Account is created');
            </script>
            <?php
        } else {
            $this->signUp();
        }
    }

    public function signUp()
    {
        $this->load->view('signup');
    }

//-----------------------------------------------------------------------------------------

    public function filter()
    {
        $username = $this->input->post("username");
        $this->load->model('user_model');
        $data['result'] = $this->user_model->search_data($username);
        $this->load->view('searchdata', $data);
    }

//--------------------------------------------------------------------------------upload file

    public function do_upload()
    {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        $this->form_validation->set_rules('academic_year', 'Academic Year', 'required');
        $this->form_validation->set_rules('subject_code', 'Subject Code', 'required');
        $this->form_validation->set_rules('semester', 'Semester', 'required');
        $this->form_validation->set_rules('year', 'Year', 'required');
        $this->form_validation->set_rules('category', 'Category', 'required');

        if ($this->form_validation->run()) {

            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'pdf';
            $config['max_size'] = '100000';
            $config['overwrite'] = true;
            $config['file_ext_tolower'] = true; // convert extension to lowercase
            $config['remove_spaces'] = true;     // remove replace underscore to spaces in file name


            $this->load->library('upload', $config);

            $this->load->model('user_model');

            if (!$this->upload->do_upload('file_name')) {

                $this->load->model('user_model');
                $data["fetch_data"] = $this->user_model->fetch_cat();
                $this->load->helper(array('form', 'url'));
                $error = array('error' => $this->upload->display_errors());
                $this->load->view('uploadfile', $data, array('error' => $this->upload->display_errors()));

            } else {


                date_default_timezone_set("Asia/Colombo");
                $date_time= date("Y-m-d") . "(" . date("h:i: sa") . ")";


                $up_file_name = $this->upload->data();

                $data = array(
                    "file_name" => $up_file_name['file_name'],
                    "date_created" => $date_time,
                    "category" => $this->input->post("category"),
                    "year" => $this->input->post("year"),
                    "semester" => $this->input->post("semester"),
                    "academic_year" => $this->input->post("academic_year"),
                    "subject_code" => $this->input->post("subject_code"),
                    "author" => $this->session->userdata('username'),
                    "comment" => $this->input->post("comment")
                );
                ?>
                <script>
                    alert('Your file was successfully uploaded!');
                    window.location.href = '<?php echo base_url();?>login_controller/uploadFile';
                </script>

                <?php
                $this->user_model->insert_file($data);
            }
        } else {
            $this->uploadFile();
        }

    }

    public function uploadFile()
    {
        $this->load->model('user_model');
        $data["fetch_data"] = $this->user_model->fetch_cat();
        $this->load->helper(array('form', 'url'));
        $this->load->view('uploadfile', $data, array('error' => ' '));
    }
    function fetch_sub(){

        if($this->input->post('category_name')) {
            $this->load->model('user_model');
            echo $this->user_model->fetch_subject($this->input->post('category_name'));
        }
    }

//--------------------------------------------------------------------------------edit file

    public function editFile()
    {
        $this->load->view('edit');
    }

    //--------------------------------------------------------------------------------Document Settings

    public function Document_Settings()
    {
        $this->load->model('user_model');
        $data["fetch_data"] = $this->user_model->fetch_cat();
        $this->load->view('DocumentSettings',$data);
    }
    public function insertCat()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('category', 'Category', 'required');

        if ($this->form_validation->run()) {

            $cat=strtolower($this->input->post('category'));
            $name=str_replace(' ', '_', $cat);

            $this->load->model('user_model');
            $data = array(
                "id" => rand(0, 100),
                "category" => $name
            );
            ?>
            <script>
                alert('One category is successfully inserted');
                window.location.href = '<?php echo base_url();?>login_controller/Document_Settings';
            </script>

            <?php

            $name=str_replace(' ', '_', $this->input->post("category"));

            $this->user_model->insert_cat($data);
            $this->load->model('user_model');
            $this->user_model->create_tables($name);


        }else{
            $this->Document_Settings();
        }
    }
    public function delete_cat()
    {
        $category = $this->uri->segment(3);
        $name=str_replace(' ', '_', $category);
        $this->load->model('user_model');
        if ($category != '') {
            $this->user_model->delete_cat($category);
            $this->user_model->delete_tables($name);
        }
        redirect(base_url() . "login_controller/Document_Settings");
    }

    public function add_subject(){

        $this->load->library('form_validation');
        $this->form_validation->set_rules('category', 'category', 'required');
        $this->form_validation->set_rules('subject_name', 'Subject Name', 'required');
        $this->form_validation->set_rules('subject_code', 'Subject Code', 'required');

        if ($this->form_validation->run()) {
            $tname=strtolower($this->input->post('category'));
            $subject_code=strtoupper($this->input->post("subject_code"));
            $this->load->model('user_model');
            $data = array(
                "subject_code" => $subject_code,
                "subject_name" => $this->input->post("subject_name")
            );
            $this->user_model->insertdata($tname,$data);
            ?>
            <script>
                alert('One category is successfully inserted');
                window.location.href = '<?php echo base_url();?>login_controller/Document_Settings';
            </script>
            <?php
        }else{
            $this->Document_Settings();
        }
    }

    public function View_cat_details(){
        $this->load->view('viewCategoryDetails');
    }

}
